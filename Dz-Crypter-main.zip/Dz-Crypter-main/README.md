# Dz-Crypter
Encrypt / Decrypt Texts



![Screenshot 2025-03-09 023224](https://github.com/user-attachments/assets/71936ba3-e889-47ec-a1a9-46cbfc5cf985)
